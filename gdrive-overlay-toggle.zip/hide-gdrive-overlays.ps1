[CmdletBinding()]
param(
    [string]$BackupRoot = "$env:ProgramData\GDriveOverlayToggle"
)

$ErrorActionPreference = 'Stop'

function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[ OK ] $Message" -ForegroundColor Green
}

function Write-WarnMsg {
    param([string]$Message)
    Write-Host "[WARN] $Message" -ForegroundColor Yellow
}

function Ensure-Admin {
    $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)

    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Host "관리자 권한으로 다시 실행합니다..." -ForegroundColor Yellow

        $argumentList = @(
            '-NoProfile'
            '-ExecutionPolicy'
            'Bypass'
            '-File'
            ('"{0}"' -f $PSCommandPath)
            '-BackupRoot'
            ('"{0}"' -f $BackupRoot)
        )

        Start-Process -FilePath 'powershell.exe' -ArgumentList ($argumentList -join ' ') -Verb RunAs | Out-Null
        exit
    }
}

function Get-RegistryDefaultValue {
    param(
        [Parameter(Mandatory = $true)]
        [string]$LiteralPath
    )

    if (-not (Test-Path -LiteralPath $LiteralPath)) {
        return $null
    }

    try {
        return (Get-Item -LiteralPath $LiteralPath -ErrorAction Stop).GetValue('')
    }
    catch {
        return $null
    }
}

function Get-OverlayBasePaths {
    $candidates = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellIconOverlayIdentifiers',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ShellIconOverlayIdentifiers',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellIconOverlayIdentifiers'
    )

    return $candidates | Where-Object { Test-Path -LiteralPath $_ }
}

function Get-ClsIdServerPath {
    param([string]$Clsid)

    if ([string]::IsNullOrWhiteSpace($Clsid)) {
        return $null
    }

    $clsidPaths = @(
        "Registry::HKEY_CLASSES_ROOT\CLSID\$Clsid\InprocServer32",
        "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\$Clsid\InprocServer32",
        "Registry::HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\$Clsid\InprocServer32"
    )

    foreach ($path in $clsidPaths) {
        $value = Get-RegistryDefaultValue -LiteralPath $path
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return $value
        }
    }

    return $null
}

function Test-IsGoogleDriveOverlay {
    param(
        [Parameter(Mandatory = $true)]
        $RegistryKey
    )

    $name = $RegistryKey.PSChildName
    $clsid = Get-RegistryDefaultValue -LiteralPath $RegistryKey.PSPath
    $serverPath = Get-ClsIdServerPath -Clsid $clsid

    $allText = @($name, $clsid, $serverPath) -join "`n"

    $patterns = @(
        'GoogleDrive',
        'Google Drive',
        'DriveFS',
        'Drive File Stream',
        'GDrive',
        'Google\\Drive',
        'Google\\Drive File Stream'
    )

    foreach ($pattern in $patterns) {
        if ($allText -match $pattern) {
            return $true
        }
    }

    return $false
}

function Restart-Explorer {
    Write-Info 'Explorer를 재시작합니다...'
    Get-Process -Name explorer -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    Start-Process explorer.exe | Out-Null
}

try {
    Ensure-Admin

    Write-Info 'Google Drive 아이콘 오버레이를 찾는 중입니다...'

    $basePaths = Get-OverlayBasePaths
    if (-not $basePaths -or $basePaths.Count -eq 0) {
        throw 'ShellIconOverlayIdentifiers 경로를 찾지 못했습니다.'
    }

    $matches = New-Object System.Collections.Generic.List[object]

    foreach ($basePath in $basePaths) {
        $items = Get-ChildItem -LiteralPath $basePath -ErrorAction Stop

        foreach ($item in $items) {
            if (Test-IsGoogleDriveOverlay -RegistryKey $item) {
                $clsid = Get-RegistryDefaultValue -LiteralPath $item.PSPath
                $serverPath = Get-ClsIdServerPath -Clsid $clsid

                $matches.Add([pscustomobject]@{
                    BasePath    = $basePath
                    KeyName     = $item.PSChildName
                    RegistryPath= $item.Name
                    PsPath      = $item.PSPath
                    Clsid       = $clsid
                    ServerPath  = $serverPath
                }) | Out-Null
            }
        }
    }

    if ($matches.Count -eq 0) {
        Write-WarnMsg 'Google Drive 오버레이 키를 찾지 못했습니다. 이미 숨김 상태이거나 현재 설치 버전의 키 이름이 다를 수 있습니다.'
        Write-Host ''
        Write-Host '아무 것도 변경하지 않았습니다.' -ForegroundColor Yellow
        exit 0
    }

    Write-Info ("찾은 오버레이 수: {0}" -f $matches.Count)
    foreach ($match in $matches) {
        Write-Host ("  - {0}" -f $match.RegistryPath)
    }

    if (-not (Test-Path -LiteralPath $BackupRoot)) {
        New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
    }

    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $backupDir = Join-Path $BackupRoot ("backup-{0}" -f $timestamp)
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

    $manifestEntries = New-Object System.Collections.Generic.List[object]
    $index = 1

    foreach ($match in $matches) {
        $safeName = ($match.KeyName -replace '[^a-zA-Z0-9._-]+', '_')
        $regFile = Join-Path $backupDir (("{0:D2}_{1}.reg" -f $index, $safeName))

        Write-Info ("백업: {0}" -f $match.RegistryPath)
        & reg.exe export $match.RegistryPath $regFile /y | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw ("레지스트리 백업에 실패했습니다: {0}" -f $match.RegistryPath)
        }

        Write-Info ("제거: {0}" -f $match.RegistryPath)
        Remove-Item -LiteralPath $match.PsPath -Recurse -Force -ErrorAction Stop

        $manifestEntries.Add([pscustomobject]@{
            KeyName      = $match.KeyName
            RegistryPath = $match.RegistryPath
            Clsid        = $match.Clsid
            ServerPath   = $match.ServerPath
            BackupFile   = [System.IO.Path]::GetFileName($regFile)
        }) | Out-Null

        $index++
    }

    $manifest = [pscustomobject]@{
        CreatedAt  = (Get-Date).ToString('o')
        Computer   = $env:COMPUTERNAME
        BackupRoot = $BackupRoot
        BackupDir  = $backupDir
        Entries    = $manifestEntries
    }

    $manifestPath = Join-Path $backupDir 'manifest.json'
    $latestPath = Join-Path $BackupRoot 'latest.txt'

    $manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $manifestPath -Encoding UTF8
    Set-Content -LiteralPath $latestPath -Value $backupDir -Encoding UTF8

    Restart-Explorer

    Write-Host ''
    Write-Ok '완료되었습니다.'
    Write-Host ("백업 폴더: {0}" -f $backupDir) -ForegroundColor Green
    Write-Host '복구가 필요하면 restore-gdrive-overlays.cmd 를 실행하시면 됩니다.' -ForegroundColor Green
    Write-Host '참고: 이 방식은 바탕화면뿐 아니라 Explorer 전체에서 Google Drive 배지를 숨깁니다.' -ForegroundColor Yellow
}
catch {
    Write-Host ''
    Write-Host '오류가 발생했습니다.' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

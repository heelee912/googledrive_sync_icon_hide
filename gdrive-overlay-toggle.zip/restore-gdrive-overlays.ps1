[CmdletBinding()]
param(
    [string]$BackupRoot = "$env:ProgramData\GDriveOverlayToggle",
    [string]$BackupPath
)

$ErrorActionPreference = 'Stop'

function Write-Info {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Cyan
}

function Write-Ok {
    param([string]$Message)
    Write-Host "[ OK ] $Message" -ForegroundColor Green
}

function Ensure-Admin {
    $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)

    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Host "관리자 권한으로 다시 실행합니다..." -ForegroundColor Yellow

        $argumentList = @(
            '-NoProfile'
            '-ExecutionPolicy'
            'Bypass'
            '-File'
            ('"{0}"' -f $PSCommandPath)
            '-BackupRoot'
            ('"{0}"' -f $BackupRoot)
        )

        if (-not [string]::IsNullOrWhiteSpace($BackupPath)) {
            $argumentList += @('-BackupPath', ('"{0}"' -f $BackupPath))
        }

        Start-Process -FilePath 'powershell.exe' -ArgumentList ($argumentList -join ' ') -Verb RunAs | Out-Null
        exit
    }
}

function Restart-Explorer {
    Write-Info 'Explorer를 재시작합니다...'
    Get-Process -Name explorer -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    Start-Process explorer.exe | Out-Null
}

function Resolve-BackupPath {
    param(
        [string]$Root,
        [string]$RequestedPath
    )

    if (-not [string]::IsNullOrWhiteSpace($RequestedPath)) {
        if (-not (Test-Path -LiteralPath $RequestedPath)) {
            throw ("지정한 백업 폴더를 찾지 못했습니다: {0}" -f $RequestedPath)
        }
        return $RequestedPath
    }

    $latestFile = Join-Path $Root 'latest.txt'
    if (Test-Path -LiteralPath $latestFile) {
        $latest = (Get-Content -LiteralPath $latestFile -ErrorAction Stop | Select-Object -First 1).Trim()
        if (-not [string]::IsNullOrWhiteSpace($latest) -and (Test-Path -LiteralPath $latest)) {
            return $latest
        }
    }

    if (-not (Test-Path -LiteralPath $Root)) {
        throw ("백업 루트를 찾지 못했습니다: {0}" -f $Root)
    }

    $folders = Get-ChildItem -LiteralPath $Root -Directory -ErrorAction Stop | Where-Object { $_.Name -like 'backup-*' } | Sort-Object LastWriteTime -Descending
    if (-not $folders -or $folders.Count -eq 0) {
        throw '복구 가능한 백업 폴더를 찾지 못했습니다.'
    }

    return $folders[0].FullName
}

try {
    Ensure-Admin

    $resolvedBackupPath = Resolve-BackupPath -Root $BackupRoot -RequestedPath $BackupPath
    Write-Info ("복구 폴더: {0}" -f $resolvedBackupPath)

    $manifestPath = Join-Path $resolvedBackupPath 'manifest.json'
    $regFiles = @()

    if (Test-Path -LiteralPath $manifestPath) {
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        foreach ($entry in $manifest.Entries) {
            $regFile = Join-Path $resolvedBackupPath $entry.BackupFile
            if (Test-Path -LiteralPath $regFile) {
                $regFiles += $regFile
            }
        }
    }

    if (-not $regFiles -or $regFiles.Count -eq 0) {
        $regFiles = Get-ChildItem -LiteralPath $resolvedBackupPath -Filter '*.reg' -File -ErrorAction Stop | Sort-Object Name | Select-Object -ExpandProperty FullName
    }

    if (-not $regFiles -or $regFiles.Count -eq 0) {
        throw '복구할 .reg 파일을 찾지 못했습니다.'
    }

    foreach ($regFile in $regFiles) {
        Write-Info ("복구: {0}" -f $regFile)
        & reg.exe import $regFile | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw ("레지스트리 복구에 실패했습니다: {0}" -f $regFile)
        }
    }

    Restart-Explorer

    Write-Host ''
    Write-Ok '복구가 완료되었습니다.'
    Write-Host 'Google Drive 배지가 다시 보이지 않으면 한 번 로그아웃 후 다시 로그인해 보시면 됩니다.' -ForegroundColor Yellow
}
catch {
    Write-Host ''
    Write-Host '오류가 발생했습니다.' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

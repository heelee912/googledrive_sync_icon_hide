Google Drive 바탕화면 배지 숨기기

1. 이 파일들을 같은 폴더에 둔 뒤 압축을 풉니다.
2. hide-gdrive-overlays.cmd 를 더블클릭합니다.
3. UAC 창이 뜨면 허용합니다.
4. Explorer가 재시작되면 Google Drive 체크표시와 동기화 배지가 숨겨집니다.

복구 방법
- restore-gdrive-overlays.cmd 를 더블클릭합니다.

중요
- 이 방식은 바탕화면만이 아니라 파일 탐색기 전체에서 Google Drive 아이콘 배지를 숨깁니다.
- 실제 동기화 자체는 끄지 않습니다.
- 백업 파일은 %ProgramData%\GDriveOverlayToggle 아래에 저장됩니다.
- Google Drive 업데이트 후 배지가 다시 생기면 hide-gdrive-overlays.cmd 를 한 번 더 실행하시면 됩니다.
